CREATE DATABASE db_test;

USE db_test;

CREATE TABLE clients (
id_client INT PRIMARY KEY,
name VARCHAR(100),
address VARCHAR(200),
email VARCHAR NOT NULL UNIQUE (150),
phone VARCHAR(15)
);

CREATE TABLE bills (
id_bill VARCHAR(20) PRIMARY KEY,
billing_period DATE,
invoiced_ammount DECIMAL(10,2)
);
DROP TABLE bills;

CREATE TABLE transaction (
transaction_id INT PRIMARY KEY UNIQUE,
dateTime DATETIME,
ammount DECIMAL(10,2),
status VARCHAR(15),
type VARCHAR (50),
platform VARCHAR (50),
ammount_pay DECIMAL(10,2)
);

